package CoreJava.MainEntryPoint;

public class TestRunner {
    public static void main(String[] args) {
//        Many things to consider working on this in the future and things I've learned.
//        You can create an array string on the fly
//        equality comparison with emails or another string should use .equals due to "@"char
//        concurrent exception errors are and should be used with an irirator or boolean out 
//        
    }
}
